import React from 'react';

function home(props) {
    return (
        <div>
            <h1 style={{color:'black',fontSize:20}}>Rejjak</h1>
        </div>
    );
}

export default home;