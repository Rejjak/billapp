import './App.css';
import MainApp from './component/mainComponent/mainapp';

function App() {
  return (
    <MainApp/>
  );
}

export default App;
